package com.hospital.appointment.service;

import com.hospital.appointment.dto.AppointmentResponse;
import com.hospital.appointment.dto.BookAppointmentRequest;
import com.hospital.appointment.entity.*;
import com.hospital.appointment.exception.BadRequestException;
import com.hospital.appointment.exception.DuplicateResourceException;
import com.hospital.appointment.repository.*;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class AppointmentService {
    private final UserRepository userRepository;
    private final PatientRepository patientRepository;
    private final AvailabilitySlotRepository slotRepository;
    private final AppointmentRepository appointmentRepository;

    public AppointmentService(UserRepository userRepository, PatientRepository patientRepository,
                              AvailabilitySlotRepository slotRepository, AppointmentRepository appointmentRepository) {
        this.userRepository = userRepository;
        this.patientRepository = patientRepository;
        this.slotRepository = slotRepository;
        this.appointmentRepository = appointmentRepository;
    }

    @Transactional
    public AppointmentResponse book(String email, BookAppointmentRequest request) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new BadRequestException("Logged-in user was not found"));
        Patient patient = patientRepository.findByUserId(user.getId())
                .orElseThrow(() -> new BadRequestException("Patient profile was not found"));
        AvailabilitySlot slot = slotRepository.findById(request.slotId())
                .orElseThrow(() -> new BadRequestException("Appointment slot was not found"));

        if (!slot.getDoctor().isApproved()) throw new BadRequestException("This doctor is not approved");
        if (slot.getStatus() != SlotStatus.AVAILABLE) throw new BadRequestException("This slot is already booked");
        if (LocalDateTime.of(slot.getSlotDate(), slot.getStartTime()).isBefore(LocalDateTime.now()))
            throw new BadRequestException("Cannot book a slot in the past");

        slot.setStatus(SlotStatus.BOOKED);
        try {
            // Flush now so a concurrent update is detected before creating the appointment.
            slotRepository.saveAndFlush(slot);
        } catch (ObjectOptimisticLockingFailureException ex) {
            throw new DuplicateResourceException("This slot was just booked by another patient. Please choose another slot.");
        }

        Appointment appointment = new Appointment();
        appointment.setPatient(patient);
        appointment.setSlot(slot);
        appointment.setReason(request.reason());
        appointment.setStatus(AppointmentStatus.BOOKED);
        return toResponse(appointmentRepository.save(appointment));
    }

    @Transactional(readOnly = true)
    public List<AppointmentResponse> myAppointments(String email) {
        return appointmentRepository.findByPatientUserEmailOrderByCreatedAtDesc(email)
                .stream().map(this::toResponse).toList();
    }

    private AppointmentResponse toResponse(Appointment a) {
        Doctor doctor = a.getSlot().getDoctor();
        return new AppointmentResponse(a.getId(), doctor.getId(), doctor.getUser().getName(),
                doctor.getSpecialization(), a.getSlot().getSlotDate(), a.getSlot().getStartTime(),
                a.getSlot().getEndTime(), a.getStatus(), a.getReason(), a.getCreatedAt());
    }
}
