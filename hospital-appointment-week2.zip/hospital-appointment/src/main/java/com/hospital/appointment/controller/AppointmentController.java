package com.hospital.appointment.controller;

import com.hospital.appointment.dto.AppointmentResponse;
import com.hospital.appointment.dto.BookAppointmentRequest;
import com.hospital.appointment.service.AppointmentService;
import jakarta.validation.Valid;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/patient/appointments")
public class AppointmentController {
    private final AppointmentService appointmentService;
    public AppointmentController(AppointmentService appointmentService) { this.appointmentService = appointmentService; }

    @PostMapping
    public AppointmentResponse book(@Valid @RequestBody BookAppointmentRequest request,
                                    @AuthenticationPrincipal User principal) {
        return appointmentService.book(principal.getUsername(), request);
    }

    @GetMapping("/my")
    public List<AppointmentResponse> myAppointments(@AuthenticationPrincipal User principal) {
        return appointmentService.myAppointments(principal.getUsername());
    }
}
