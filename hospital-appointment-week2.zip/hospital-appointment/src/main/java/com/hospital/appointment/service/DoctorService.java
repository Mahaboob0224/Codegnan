package com.hospital.appointment.service;

import com.hospital.appointment.dto.CreateSlotRequest;
import com.hospital.appointment.dto.DoctorResponse;
import com.hospital.appointment.dto.SlotResponse;
import com.hospital.appointment.entity.*;
import com.hospital.appointment.exception.BadRequestException;
import com.hospital.appointment.repository.*;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDate;
import java.util.List;

@Service
public class DoctorService {
    private final DoctorRepository doctorRepository;
    private final UserRepository userRepository;
    private final AvailabilitySlotRepository slotRepository;

    public DoctorService(DoctorRepository doctorRepository, UserRepository userRepository,
                         AvailabilitySlotRepository slotRepository) {
        this.doctorRepository = doctorRepository;
        this.userRepository = userRepository;
        this.slotRepository = slotRepository;
    }

    @Transactional(readOnly = true)
    public Page<DoctorResponse> searchDoctors(String specialization, Pageable pageable) {
        Page<Doctor> doctors = (specialization == null || specialization.isBlank())
                ? doctorRepository.findByApprovedTrue(pageable)
                : doctorRepository.findByApprovedTrueAndSpecializationContainingIgnoreCase(specialization.trim(), pageable);
        return doctors.map(this::toDoctorResponse);
    }

    @Transactional
    public SlotResponse createSlot(String email, CreateSlotRequest request) {
        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new BadRequestException("Logged-in user was not found"));
        Doctor doctor = doctorRepository.findByUserId(user.getId())
                .orElseThrow(() -> new BadRequestException("Doctor profile was not found"));
        if (!doctor.isApproved()) throw new BadRequestException("Your doctor profile must be approved before adding slots");
        if (request.slotDate().isBefore(LocalDate.now())) throw new BadRequestException("Slot date cannot be in the past");
        if (!request.endTime().isAfter(request.startTime())) throw new BadRequestException("End time must be after start time");
        if (slotRepository.existsByDoctorIdAndSlotDateAndStartTimeLessThanAndEndTimeGreaterThan(
                doctor.getId(), request.slotDate(), request.endTime(), request.startTime()))
            throw new BadRequestException("This slot overlaps with an existing slot");

        AvailabilitySlot slot = new AvailabilitySlot();
        slot.setDoctor(doctor);
        slot.setSlotDate(request.slotDate());
        slot.setStartTime(request.startTime());
        slot.setEndTime(request.endTime());
        slot.setStatus(SlotStatus.AVAILABLE);
        return toSlotResponse(slotRepository.save(slot));
    }

    @Transactional(readOnly = true)
    public List<SlotResponse> getAvailableSlots(Long doctorId, LocalDate date) {
        if (!doctorRepository.existsById(doctorId)) throw new BadRequestException("Doctor was not found");
        return slotRepository.findByDoctorIdAndSlotDateAndStatusOrderByStartTimeAsc(doctorId, date, SlotStatus.AVAILABLE)
                .stream().map(this::toSlotResponse).toList();
    }

    @Transactional(readOnly = true)
    public List<DoctorResponse> getPendingDoctors() {
        return doctorRepository.findByApprovedFalseOrderByIdAsc().stream()
                .map(this::toDoctorResponse).toList();
    }

    @Transactional
    public DoctorResponse approveDoctor(Long doctorId) {
        Doctor doctor = doctorRepository.findById(doctorId)
                .orElseThrow(() -> new BadRequestException("Doctor was not found"));
        doctor.setApproved(true);
        return toDoctorResponse(doctorRepository.save(doctor));
    }

    private DoctorResponse toDoctorResponse(Doctor d) {
        return new DoctorResponse(d.getId(), d.getUser().getName(), d.getSpecialization(),
                d.getExperienceYears(), d.getFee(), d.isApproved());
    }

    private SlotResponse toSlotResponse(AvailabilitySlot s) {
        return new SlotResponse(s.getId(), s.getDoctor().getId(), s.getSlotDate(),
                s.getStartTime(), s.getEndTime(), s.getStatus());
    }
}
