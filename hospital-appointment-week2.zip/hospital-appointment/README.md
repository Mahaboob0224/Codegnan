# Hospital Appointment Booking System

A Java full-stack hospital appointment booking system. The Spring Boot backend exposes REST APIs for patient, doctor, and admin workflows. The frontend will be built with HTML, CSS, and JavaScript and will consume these APIs.

**Backend stack:** Java 21 (project is compatible with Java 17+), Spring Boot 3, Spring Security + JWT, Spring Data JPA, Hibernate, MySQL, Maven, Swagger/OpenAPI.
**Frontend stack:** HTML, CSS, JavaScript (to be added in the frontend milestone).

## Project status

- [x] Week 1: project setup, entities, registration, JWT login, role-based access
- [x] Week 2 backend: doctor search + pagination, admin doctor approval, doctor availability slots, patient booking, optimistic locking
- [ ] Week 3: cancellation/rescheduling, email notifications, additional automated tests
- [ ] Week 4: frontend screens, integration, README screenshots, deployment

## Run locally

1. Install Java 21 (Java 17+ is supported), Maven, and MySQL.
2. Ensure MySQL is running. In `src/main/resources/application.properties`, set the database username/password, or use `DB_USERNAME` and `DB_PASSWORD` environment variables. The `hospital_db` database is created automatically.
3. Run from the project root:
   ```bash
   mvn spring-boot:run
   ```
4. Open Swagger UI: http://localhost:8080/swagger-ui.html

A default admin is created on first start: `admin@hospital.com` / `Admin@123`. Change this before any public deployment.

## Authentication

Register and login using:
- `POST /api/auth/register`
- `POST /api/auth/login`

For protected endpoints, send `Authorization: Bearer <token>`.

Example patient registration:
```json
{
  "name": "Ravi",
  "email": "ravi@test.com",
  "password": "secret123",
  "role": "PATIENT",
  "age": 25,
  "gender": "Male",
  "phone": "9999999999"
}
```

Example doctor registration:
```json
{
  "name": "Dr. Anita",
  "email": "anita@test.com",
  "password": "secret123",
  "role": "DOCTOR",
  "specialization": "Cardiology",
  "experienceYears": 8,
  "fee": 500
}
```

New doctor profiles require admin approval before they appear in public search or can create slots.

## Week 2 APIs

| Method | Endpoint | Access | Purpose |
|---|---|---|---|
| GET | `/api/doctors?specialization=Cardiology&page=0&size=10` | Public | Search approved doctors with pagination |
| GET | `/api/admin/doctors/pending` | ADMIN | List doctors waiting for approval |
| PUT | `/api/admin/doctors/{doctorId}/approve` | ADMIN | Approve a doctor |
| POST | `/api/doctor/slots` | DOCTOR | Create an availability slot |
| GET | `/api/doctors/{doctorId}/slots?date=2026-11-20` | Public | List available slots for a date |
| POST | `/api/patient/appointments` | PATIENT | Book a slot |
| GET | `/api/patient/appointments/my` | PATIENT | View own appointments |

Create slot request:
```json
{
  "slotDate": "2026-11-20",
  "startTime": "10:00:00",
  "endTime": "10:30:00"
}
```

Book appointment request:
```json
{
  "slotId": 1,
  "reason": "General consultation"
}
```

## Booking concurrency

`AvailabilitySlot` has a JPA `@Version` field. When a patient books a slot, the application changes its status from `AVAILABLE` to `BOOKED` and flushes the update. If another request changed the same slot first, Hibernate detects the stale version and the second booking is rejected. The appointment is saved only after the slot update succeeds.

## Tests

Run automated tests with:
```bash
mvn test
```
